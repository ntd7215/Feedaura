/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.hud;

import dev.feedaura.FeedAura;
import dev.feedaura.FeedAura.SpeciesStat;
import dev.feedaura.FeedAuraConfig;
import dev.feedaura.FeedAuraConfig.LimitMode;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Small on-screen list: "Armadillo: 12/20 | fed 7". */
public final class CounterHud
{
    private CounterHud()
    {}
    
    public static void render(GuiGraphics graphics, DeltaTracker tickCounter)
    {
        Minecraft mc = Minecraft.getInstance();
        FeedAuraConfig cfg = FeedAuraConfig.get();
        if(!cfg.showHud || !FeedAura.INSTANCE.isEnabled() || mc.player == null)
            return;
        
        int x = 6;
        int y = 6;
        graphics.drawString(mc.font, Component.translatable("feedaura.hud.title"),
            x, y, 0xFFFFAA00);
        y += 11;
        
        if(FeedAura.INSTANCE.getStats().isEmpty())
        {
            graphics.drawString(mc.font, Component.translatable("feedaura.hud.hint"),
                x, y, 0xFFAAAAAA);
            return;
        }
        
        for(SpeciesStat stat : FeedAura.INSTANCE.getStats())
        {
            String count = String.valueOf(stat.population());
            if(cfg.limitEnabled && cfg.limitMode == LimitMode.POPULATION)
                count += "/" + cfg.limit;
            
            String fed = " | " + Component.translatable("feedaura.hud.fed").getString()
                + " " + stat.fed();
            if(cfg.limitEnabled && cfg.limitMode == LimitMode.FED)
                fed += "/" + cfg.limit;
            
            MutableComponent line = stat.name().copy()
                .append(Component.literal(": " + count + fed));
            if(stat.limited())
                line.append(Component.literal(" ")
                    .append(Component.translatable("feedaura.hud.limit_reached")));
            
            graphics.drawString(mc.font, line, x, y,
                stat.limited() ? 0xFFFF5555 : 0xFF55FF55);
            y += 10;
        }
    }
}
