/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.feedaura.FeedAura;
import dev.feedaura.FeedAuraConfig;
import dev.feedaura.util.EntityUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Draws the green-to-red box around the entity that will be fed next.
 * Port of the render code in Wurst's FeedAuraHack/RenderUtils.
 *
 * Differences from Wurst: uses vanilla render types, so the box is hidden
 * behind blocks (Wurst drew it through walls with custom shaders).
 *
 * If this file ever fails to compile on a different Minecraft version, you can
 * simply delete it together with LevelRendererMixin (and its entry in
 * feedaura.mixins.json) - the rest of the mod does not depend on it.
 */
public final class TargetHighlighter
{
    private TargetHighlighter()
    {}
    
    public static void render(PoseStack matrices, float partialTicks)
    {
        FeedAuraConfig cfg = FeedAuraConfig.get();
        LivingEntity renderTarget = FeedAura.INSTANCE.getRenderTarget();
        if(!cfg.highlightTarget || renderTarget == null)
            return;
        
        Minecraft mc = Minecraft.getInstance();
        
        float p = 1;
        if(renderTarget.getMaxHealth() > 1e-5)
            p = renderTarget.getHealth() / renderTarget.getMaxHealth();
        float green = p * 2F;
        float red = 2 - green;
        int quadColor = toIntColor(red, green, 0, 0.25F);
        int lineColor = toIntColor(red, green, 0, 0.5F);
        
        AABB box = EntityUtils.getLerpedBox(renderTarget, partialTicks);
        if(p < 1)
            box = box.deflate((1 - p) * 0.5 * box.getXsize(),
                (1 - p) * 0.5 * box.getYsize(), (1 - p) * 0.5 * box.getZsize());
        
        // the matrix stack is camera-relative, so shift the box by the camera position
        Vec3 cam = mc.gameRenderer.getMainCamera().position();
        box = box.move(-cam.x, -cam.y, -cam.z);
        
        MultiBufferSource.BufferSource buffers =
            mc.renderBuffers().bufferSource();
        
        RenderType quadLayer = RenderType.debugQuads();
        drawSolidBox(matrices, buffers.getBuffer(quadLayer), box, quadColor);
        buffers.endBatch(quadLayer);
        
        RenderType lineLayer = RenderType.lines();
        drawOutlinedBox(matrices, buffers.getBuffer(lineLayer), box, lineColor);
        buffers.endBatch(lineLayer);
    }
    
    private static int toIntColor(float r, float g, float b, float opacity)
    {
        return (int)(Mth.clamp(opacity, 0, 1) * 255) << 24
            | (int)(Mth.clamp(r, 0, 1) * 255) << 16
            | (int)(Mth.clamp(g, 0, 1) * 255) << 8
            | (int)(Mth.clamp(b, 0, 1) * 255);
    }
    
    private static void drawSolidBox(PoseStack matrices, VertexConsumer buffer,
        AABB box, int color)
    {
        PoseStack.Pose entry = matrices.last();
        float x1 = (float)box.minX;
        float y1 = (float)box.minY;
        float z1 = (float)box.minZ;
        float x2 = (float)box.maxX;
        float y2 = (float)box.maxY;
        float z2 = (float)box.maxZ;
        
        quad(buffer, entry, color, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);
        quad(buffer, entry, color, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1);
        quad(buffer, entry, color, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1);
        quad(buffer, entry, color, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);
        quad(buffer, entry, color, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2);
        quad(buffer, entry, color, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1);
    }
    
    private static void quad(VertexConsumer buffer, PoseStack.Pose entry,
        int color, float ax, float ay, float az, float bx, float by, float bz,
        float cx, float cy, float cz, float dx, float dy, float dz)
    {
        buffer.addVertex(entry, ax, ay, az).setColor(color);
        buffer.addVertex(entry, bx, by, bz).setColor(color);
        buffer.addVertex(entry, cx, cy, cz).setColor(color);
        buffer.addVertex(entry, dx, dy, dz).setColor(color);
    }
    
    private static void drawOutlinedBox(PoseStack matrices,
        VertexConsumer buffer, AABB box, int color)
    {
        PoseStack.Pose e = matrices.last();
        float x1 = (float)box.minX;
        float y1 = (float)box.minY;
        float z1 = (float)box.minZ;
        float x2 = (float)box.maxX;
        float y2 = (float)box.maxY;
        float z2 = (float)box.maxZ;
        
        // bottom + top
        for(float y : new float[]{y1, y2})
        {
            line(buffer, e, color, x1, y, z1, x2, y, z1, 1, 0, 0);
            line(buffer, e, color, x1, y, z1, x1, y, z2, 0, 0, 1);
            line(buffer, e, color, x2, y, z1, x2, y, z2, 0, 0, 1);
            line(buffer, e, color, x1, y, z2, x2, y, z2, 1, 0, 0);
        }
        
        // vertical edges
        line(buffer, e, color, x1, y1, z1, x1, y2, z1, 0, 1, 0);
        line(buffer, e, color, x2, y1, z1, x2, y2, z1, 0, 1, 0);
        line(buffer, e, color, x1, y1, z2, x1, y2, z2, 0, 1, 0);
        line(buffer, e, color, x2, y1, z2, x2, y2, z2, 0, 1, 0);
    }
    
    private static void line(VertexConsumer buffer, PoseStack.Pose entry,
        int color, float x1, float y1, float z1, float x2, float y2, float z2,
        float nx, float ny, float nz)
    {
        buffer.addVertex(entry, x1, y1, z1).setColor(color)
            .setNormal(entry, nx, ny, nz).setLineWidth(2);
        buffer.addVertex(entry, x2, y2, z2).setColor(color)
            .setNormal(entry, nx, ny, nz).setLineWidth(2);
    }
}
