/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.util;

import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
// NOTE: nếu build báo lỗi import ở dòng dưới, Mojang đã đổi package của AbstractHorse
// (ví dụ ...animal.equine.AbstractHorse). Chỉ cần sửa đúng 1 dòng import này.
import net.minecraft.world.entity.animal.horse.AbstractHorse;

/** The few entity checks that FeedAura's filters need. */
public enum EntityKinds
{
    ;
    
    /** Same logic as Wurst's FilterBabiesSetting: true = entity may be fed. */
    public static boolean passesBabyFilter(Entity e)
    {
        // never filter out hostile mobs (including hoglins)
        if(e instanceof Enemy)
            return true;
        
        // filter out passive entity babies
        if(e instanceof AgeableMob mob && mob.isBaby())
            return false;
        
        // filter out tadpoles
        if(e.getType() == EntityType.TADPOLE)
            return false;
        
        return true;
    }
    
    public static boolean isHorseLike(Entity e)
    {
        return e instanceof AbstractHorse;
    }
    
    public static boolean isUntamed(Entity e)
    {
        if(e instanceof AbstractHorse horse && !horse.isTamed())
            return true;
        
        if(e instanceof TamableAnimal tame && !tame.isTame())
            return true;
        
        return false;
    }
}
