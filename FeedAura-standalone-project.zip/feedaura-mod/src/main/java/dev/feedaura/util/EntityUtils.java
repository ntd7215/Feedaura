/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.util;

import java.util.Optional;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public enum EntityUtils
{
    ;
    
    /** Distance (squared) from the player's eyes to the closest point of the entity's hitbox. */
    public static double distanceToHitboxSq(Entity e)
    {
        Vec3 start = Minecraft.getInstance().player.getEyePosition();
        AABB box = e.getBoundingBox();
        double x = Mth.clamp(start.x, box.minX, box.maxX);
        double y = Mth.clamp(start.y, box.minY, box.maxY);
        double z = Mth.clamp(start.z, box.minZ, box.maxZ);
        return start.distanceToSqr(new Vec3(x, y, z));
    }
    
    public static EntityHitResult createHitResult(Entity e)
    {
        AABB box = e.getBoundingBox();
        Vec3 start = Minecraft.getInstance().player.getEyePosition();
        Vec3 end = box.getCenter();
        Optional<Vec3> clip = box.clip(start, end);
        Vec3 hitVec = clip.orElse(start);
        return new EntityHitResult(e, hitVec);
    }
    
    /** Bounding box interpolated between the last and current tick (smooth rendering). */
    public static AABB getLerpedBox(Entity e, float partialTicks)
    {
        if(e.isRemoved())
            return e.getBoundingBox();
        
        double x = Mth.lerp((double)partialTicks, e.xOld, e.getX());
        double y = Mth.lerp((double)partialTicks, e.yOld, e.getY());
        double z = Mth.lerp((double)partialTicks, e.zOld, e.getZ());
        Vec3 offset = new Vec3(x, y, z).subtract(e.position());
        return e.getBoundingBox().move(offset);
    }
}
