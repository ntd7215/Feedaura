/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.InputConstants;

import dev.feedaura.gui.FeedAuraScreen;
import dev.feedaura.hud.CounterHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class FeedAuraMod implements ClientModInitializer
{
    public static final String MOD_ID = "feedaura";
    
    private static KeyMapping toggleKey;
    private static KeyMapping guiKey;
    
    @Override
    public void onInitializeClient()
    {
        FeedAuraConfig.load();
        
        KeyMapping.Category category = KeyMapping.Category
            .register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        
        toggleKey = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key.feedaura.toggle", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_J, category));
        guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key.feedaura.gui", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        
        // feeding logic (equivalent of Wurst's HandleInput + Update events)
        ClientTickEvents.START_CLIENT_TICK.register(FeedAura.INSTANCE::tick);
        
        // hotkeys
        ClientTickEvents.END_CLIENT_TICK.register(FeedAuraMod::handleKeys);
        
        // on-screen counter
        HudElementRegistry.addLast(
            Identifier.fromNamespaceAndPath(MOD_ID, "counter"),
            CounterHud::render);
    }
    
    private static void handleKeys(Minecraft mc)
    {
        while(toggleKey.consumeClick())
        {
            FeedAura.INSTANCE.toggle();
            if(mc.player != null)
                mc.player.displayClientMessage(Component.translatable(
                    FeedAura.INSTANCE.isEnabled() ? "feedaura.msg.on"
                        : "feedaura.msg.off"),
                    true);
        }
        
        while(guiKey.consumeClick())
            if(mc.player != null && mc.screen == null)
                mc.setScreen(new FeedAuraScreen(null));
    }
}
