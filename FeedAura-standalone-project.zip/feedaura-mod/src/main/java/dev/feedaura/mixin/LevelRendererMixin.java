/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.mixin;

import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.blaze3d.vertex.PoseStack;

import dev.feedaura.render.TargetHighlighter;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.LevelRenderer;

/** Draws the target highlight after the world has been rendered. */
@Mixin(LevelRenderer.class)
public class LevelRendererMixin
{
    @Inject(
        method = "renderLevel(Lcom/mojang/blaze3d/resource/GraphicsResourceAllocator;Lnet/minecraft/client/DeltaTracker;ZLnet/minecraft/client/Camera;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V",
        at = @At("RETURN"))
    private void feedaura$onRender(GraphicsResourceAllocator allocator,
        DeltaTracker tickCounter, boolean renderBlockOutline, Camera camera,
        Matrix4f positionMatrix, Matrix4f projectionMatrix, Matrix4f matrix4f2,
        GpuBufferSlice gpuBufferSlice, Vector4f vector4f, boolean bl,
        CallbackInfo ci)
    {
        PoseStack matrixStack = new PoseStack();
        matrixStack.mulPose(positionMatrix);
        float tickProgress = tickCounter.getGameTimeDeltaPartialTick(false);
        TargetHighlighter.render(matrixStack, tickProgress);
    }
}
