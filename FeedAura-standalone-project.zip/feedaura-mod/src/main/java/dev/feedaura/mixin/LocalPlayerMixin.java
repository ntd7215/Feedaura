/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.feedaura.RotationFaker;
import net.minecraft.client.player.LocalPlayer;

/** Swaps in the fake rotation only while the movement packet is being built. */
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin
{
    @Inject(method = "sendPosition()V", at = @At("HEAD"))
    private void feedaura$onPreMotion(CallbackInfo ci)
    {
        RotationFaker.onPreMotion((LocalPlayer)(Object)this);
    }
    
    @Inject(method = "sendPosition()V", at = @At("TAIL"))
    private void feedaura$onPostMotion(CallbackInfo ci)
    {
        RotationFaker.onPostMotion((LocalPlayer)(Object)this);
    }
}
