/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Makes the server see the player looking at the target without moving the
 * player's real camera. Port of Wurst's RotationFaker (faceVectorPacket only).
 */
public final class RotationFaker
{
    private static boolean fakeRotation;
    private static float serverYaw;
    private static float serverPitch;
    private static float realYaw;
    private static float realPitch;
    
    private RotationFaker()
    {}
    
    /** Called at the start of LocalPlayer.sendPosition(). */
    public static void onPreMotion(LocalPlayer player)
    {
        if(!fakeRotation)
            return;
        
        realYaw = player.getYRot();
        realPitch = player.getXRot();
        player.setYRot(serverYaw);
        player.setXRot(serverPitch);
    }
    
    /** Called at the end of LocalPlayer.sendPosition(). */
    public static void onPostMotion(LocalPlayer player)
    {
        if(!fakeRotation)
            return;
        
        player.setYRot(realYaw);
        player.setXRot(realPitch);
        fakeRotation = false;
    }
    
    public static void faceVectorPacket(LocalPlayer player, Vec3 vec)
    {
        Vec3 eyes = player.getEyePosition();
        double diffX = vec.x - eyes.x;
        double diffZ = vec.z - eyes.z;
        double yaw = Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        
        double diffY = vec.y - eyes.y;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        double pitch = -Math.toDegrees(Math.atan2(diffY, diffXZ));
        
        fakeRotation = true;
        serverYaw = limitAngleChange(player.getYRot(),
            Mth.wrapDegrees((float)yaw));
        serverPitch = Mth.wrapDegrees((float)pitch);
    }
    
    /** Removes unnecessary changes in angle caused by wrapping. */
    private static float limitAngleChange(float current, float intended)
    {
        float currentWrapped = Mth.wrapDegrees(current);
        float intendedWrapped = Mth.wrapDegrees(intended);
        float change = Mth.wrapDegrees(intendedWrapped - currentWrapped);
        return current + change;
    }
}
