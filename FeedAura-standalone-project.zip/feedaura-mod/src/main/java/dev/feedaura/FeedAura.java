/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import dev.feedaura.FeedAuraConfig.LimitMode;
import dev.feedaura.util.EntityKinds;
import dev.feedaura.util.EntityUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Feeds nearby animals with the item in your hand (port of Wurst's FeedAura),
 * plus a per-species counter and an optional stop-at-limit.
 */
public final class FeedAura
{
    public static final FeedAura INSTANCE = new FeedAura();
    
    /** One line of the on-screen counter. */
    public record SpeciesStat(Component name, int population, int fed,
        boolean limited)
    {}
    
    private final Random random = new Random();
    private final Map<EntityType<?>, Integer> fedBySpecies = new HashMap<>();
    
    private boolean enabled;
    private LivingEntity target;
    private LivingEntity renderTarget;
    private List<SpeciesStat> stats = List.of();
    
    private FeedAura()
    {}
    
    public boolean isEnabled()
    {
        return enabled;
    }
    
    public void setEnabled(boolean enabled)
    {
        if(this.enabled == enabled)
            return;
        
        this.enabled = enabled;
        target = null;
        renderTarget = null;
        
        if(enabled)
            resetFedCounter();
        else
            stats = List.of();
    }
    
    public void toggle()
    {
        setEnabled(!enabled);
    }
    
    public void resetFedCounter()
    {
        fedBySpecies.clear();
    }
    
    public LivingEntity getRenderTarget()
    {
        return renderTarget;
    }
    
    public List<SpeciesStat> getStats()
    {
        return stats;
    }
    
    /**
     * Called once at the start of every client tick. Same order as Wurst:
     * first interact with the target picked last tick, then pick a new one.
     */
    public void tick(Minecraft mc)
    {
        if(!enabled)
            return;
        
        if(mc.player == null || mc.level == null || mc.gameMode == null)
        {
            target = null;
            renderTarget = null;
            return;
        }
        
        if(mc.isPaused())
            return;
        
        handleInput(mc);
        update(mc);
    }
    
    private void update(Minecraft mc)
    {
        LocalPlayer player = mc.player;
        FeedAuraConfig cfg = FeedAuraConfig.get();
        ItemStack heldStack = player.getInventory().getSelectedItem();
        
        double rangeSq = cfg.range * cfg.range;
        double countRange =
            cfg.countRange <= 0 ? 0 : Math.max(cfg.countRange, cfg.range);
        double countRangeSq = countRange * countRange;
        
        // 1) walk through all animals once: count them and collect candidates
        Map<EntityType<?>, Integer> population = new LinkedHashMap<>();
        List<Animal> candidates = new ArrayList<>();
        
        if(!heldStack.isEmpty())
            for(Entity e : mc.level.entitiesForRendering())
            {
                if(!(e instanceof Animal animal) || !animal.isAlive())
                    continue;
                
                // only animals that accept the item in your hand
                if(!animal.isFood(heldStack))
                    continue;
                
                if(countRange <= 0 || player.distanceToSqr(animal) <= countRangeSq)
                    population.merge(animal.getType(), 1, Integer::sum);
                
                if(EntityUtils.distanceToHitboxSq(animal) <= rangeSq
                    && animal.canFallInLove())
                    candidates.add(animal);
            }
        
        // 2) counter for the HUD
        List<SpeciesStat> newStats = new ArrayList<>();
        for(Map.Entry<EntityType<?>, Integer> entry : population.entrySet())
        {
            EntityType<?> type = entry.getKey();
            int pop = entry.getValue();
            newStats.add(new SpeciesStat(type.getDescription(), pop,
                fedBySpecies.getOrDefault(type, 0),
                cfg.limitEnabled && isAtLimit(cfg, type, pop)));
        }
        stats = newStats;
        
        // 3) filters (same as Wurst) + limit
        List<LivingEntity> targets = new ArrayList<>();
        for(Animal animal : candidates)
        {
            if(cfg.filterBabies && !EntityKinds.passesBabyFilter(animal))
                continue;
            
            if(cfg.filterUntamed && EntityKinds.isUntamed(animal))
                continue;
            
            if(cfg.filterHorses && EntityKinds.isHorseLike(animal))
                continue;
            
            if(cfg.limitEnabled && isAtLimit(cfg, animal.getType(),
                population.getOrDefault(animal.getType(), 0)))
                continue;
            
            targets.add(animal);
        }
        
        // 4) pick a target at random
        target = targets.isEmpty() ? null
            : targets.get(random.nextInt(targets.size()));
        
        renderTarget = target;
        if(target == null)
            return;
        
        RotationFaker.faceVectorPacket(player, target.getBoundingBox().getCenter());
    }
    
    private boolean isAtLimit(FeedAuraConfig cfg, EntityType<?> type,
        int population)
    {
        if(cfg.limitMode == LimitMode.POPULATION)
            return population >= cfg.limit;
        
        return fedBySpecies.getOrDefault(type, 0) >= cfg.limit;
    }
    
    private void handleInput(Minecraft mc)
    {
        if(target == null)
            return;
        
        MultiPlayerGameMode gm = mc.gameMode;
        LocalPlayer player = mc.player;
        
        if(gm.isDestroying() || player.isHandsBusy())
            return;
        
        LivingEntity entity = target;
        target = null;
        
        if(entity.isRemoved())
            return;
        
        EntityHitResult hitResult = EntityUtils.createHitResult(entity);
        InteractionHand hand = InteractionHand.MAIN_HAND;
        
        InteractionResult result = gm.interactAt(player, entity, hitResult, hand);
        if(!result.consumesAction())
            result = gm.interact(player, entity, hand);
        
        if(result.consumesAction())
            fedBySpecies.merge(entity.getType(), 1, Integer::sum);
        
        if(result instanceof InteractionResult.Success success
            && success.swingSource() == InteractionResult.SwingSource.CLIENT)
            player.swing(hand);
    }
}
