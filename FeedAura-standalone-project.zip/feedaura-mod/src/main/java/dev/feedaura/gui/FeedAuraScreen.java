/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura.gui;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;

import dev.feedaura.FeedAura;
import dev.feedaura.FeedAuraConfig;
import dev.feedaura.FeedAuraConfig.LimitMode;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Settings screen: open with the "FeedAura settings" key (default: Right Shift). */
public final class FeedAuraScreen extends Screen
{
    private final Screen parent;
    private final FeedAuraConfig cfg = FeedAuraConfig.get();
    
    private EditBox limitBox;
    private int titleY;
    private int captionX;
    private int captionY;
    
    public FeedAuraScreen(Screen parent)
    {
        super(Component.translatable("feedaura.gui.title"));
        this.parent = parent;
    }
    
    @Override
    protected void init()
    {
        int colW = 150;
        int gap = 10;
        int rowH = 24;
        int leftX = width / 2 - colW - gap / 2;
        int rightX = width / 2 + gap / 2;
        int top = Math.max(32, height / 2 - 84);
        titleY = top - 20;
        
        // ---------- left column: original FeedAura settings ----------
        int y = top;
        addRenderableWidget(new ValueSlider(leftX, y, colW, 20, 1, 10, 0.05,
            cfg.range,
            v -> Component.translatable("feedaura.gui.range", fmt(v)),
            v -> cfg.range = v, "feedaura.tip.range"));
        y += rowH;
        
        addToggle(leftX, y, colW, "feedaura.gui.filter_babies",
            () -> cfg.filterBabies, v -> cfg.filterBabies = v,
            "feedaura.tip.filter_babies");
        y += rowH;
        
        addToggle(leftX, y, colW, "feedaura.gui.filter_untamed",
            () -> cfg.filterUntamed, v -> cfg.filterUntamed = v,
            "feedaura.tip.filter_untamed");
        y += rowH;
        
        addToggle(leftX, y, colW, "feedaura.gui.filter_horses",
            () -> cfg.filterHorses, v -> cfg.filterHorses = v,
            "feedaura.tip.filter_horses");
        y += rowH;
        
        addToggle(leftX, y, colW, "feedaura.gui.show_hud", () -> cfg.showHud,
            v -> cfg.showHud = v, null);
        y += rowH;
        
        addToggle(leftX, y, colW, "feedaura.gui.highlight",
            () -> cfg.highlightTarget, v -> cfg.highlightTarget = v, null);
        
        // ---------- right column: on/off + counter + limit ----------
        y = top;
        addToggle(rightX, y, colW, "feedaura.gui.enabled",
            FeedAura.INSTANCE::isEnabled, FeedAura.INSTANCE::setEnabled, null);
        y += rowH;
        
        addToggle(rightX, y, colW, "feedaura.gui.limit_enabled",
            () -> cfg.limitEnabled, v -> cfg.limitEnabled = v,
            "feedaura.tip.limit");
        y += rowH;
        
        Button modeButton = Button.builder(modeLabel(), b -> {
            cfg.limitMode = cfg.limitMode.next();
            b.setMessage(modeLabel());
        }).bounds(rightX, y, colW, 20).build();
        modeButton.setTooltip(
            Tooltip.create(Component.translatable("feedaura.tip.limit_mode")));
        addRenderableWidget(modeButton);
        y += rowH;
        
        // caption + [-] [ number ] [+]
        captionX = rightX;
        captionY = y;
        y += 11;
        
        limitBox = new EditBox(font, rightX + 22, y, colW - 44, 20,
            Component.translatable("feedaura.gui.limit_value"));
        limitBox.setMaxLength(4);
        limitBox.setFilter(s -> s.matches("\\d*"));
        limitBox.setValue(String.valueOf(cfg.limit));
        limitBox.setResponder(s -> {
            if(!s.isEmpty())
                cfg.limit = Mth.clamp(Integer.parseInt(s), 1, 9999);
        });
        addRenderableWidget(limitBox);
        addRenderableWidget(Button.builder(Component.literal("-"), b -> changeLimit(-1))
            .bounds(rightX, y, 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> changeLimit(1))
            .bounds(rightX + colW - 20, y, 20, 20).build());
        y += rowH;
        
        addRenderableWidget(new ValueSlider(rightX, y, colW, 20, 0, 128, 1,
            cfg.countRange,
            v -> v <= 0
                ? Component.translatable("feedaura.gui.count_range",
                    Component.translatable("feedaura.gui.count_range_all"))
                : Component.translatable("feedaura.gui.count_range", fmt(v)),
            v -> cfg.countRange = v, "feedaura.tip.count_range"));
        y += rowH;
        
        addRenderableWidget(
            Button.builder(Component.translatable("feedaura.gui.reset"),
                b -> FeedAura.INSTANCE.resetFedCounter())
                .bounds(rightX, y, colW, 20).build());
        
        // ---------- done ----------
        addRenderableWidget(
            Button.builder(Component.translatable("feedaura.gui.done"),
                b -> onClose())
                .bounds(width / 2 - 100, top + 6 * rowH + 10, 200, 20)
                .build());
    }
    
    private void changeLimit(int delta)
    {
        int step = hasShiftDown() ? 10 : 1;
        int value = Mth.clamp(cfg.limit + delta * step, 1, 9999);
        limitBox.setValue(String.valueOf(value));
    }
    
    private Component modeLabel()
    {
        String key = cfg.limitMode == LimitMode.POPULATION
            ? "feedaura.gui.mode.population" : "feedaura.gui.mode.fed";
        return Component.translatable("feedaura.gui.limit_mode",
            Component.translatable(key));
    }
    
    private static String fmt(double v)
    {
        return String.format(Locale.ROOT, v == Math.rint(v) ? "%.0f" : "%.2f", v);
    }
    
    private static Component onOff(boolean value)
    {
        return Component.translatable(value ? "feedaura.gui.on" : "feedaura.gui.off");
    }
    
    private void addToggle(int x, int y, int w, String key,
        BooleanSupplier getter, Consumer<Boolean> setter, String tooltipKey)
    {
        Button button = Button.builder(Component.translatable(key, onOff(getter.getAsBoolean())),
            b -> {
                setter.accept(!getter.getAsBoolean());
                b.setMessage(Component.translatable(key, onOff(getter.getAsBoolean())));
            }).bounds(x, y, w, 20).build();
        
        if(tooltipKey != null)
            button.setTooltip(Tooltip.create(Component.translatable(tooltipKey)));
        
        addRenderableWidget(button);
    }
    
    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY,
        float partialTick)
    {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(font, title, width / 2, titleY, 0xFFFFFFFF);
        graphics.drawString(font, Component.translatable("feedaura.gui.limit_value"),
            captionX, captionY, 0xFFAAAAAA);
    }
    
    @Override
    public boolean isPauseScreen()
    {
        // keep the world running so you can watch the counter while tuning
        return false;
    }
    
    @Override
    public void onClose()
    {
        FeedAuraConfig.save();
        minecraft.setScreen(parent);
    }
    
    /** Slider with a min, max and step that writes straight into the config. */
    private static final class ValueSlider extends AbstractSliderButton
    {
        private final double min;
        private final double max;
        private final double step;
        private final DoubleFunction<Component> label;
        private final DoubleConsumer onChange;
        
        ValueSlider(int x, int y, int w, int h, double min, double max,
            double step, double initial, DoubleFunction<Component> label,
            DoubleConsumer onChange, String tooltipKey)
        {
            super(x, y, w, h, Component.empty(), (initial - min) / (max - min));
            this.min = min;
            this.max = max;
            this.step = step;
            this.label = label;
            this.onChange = onChange;
            updateMessage();
            
            if(tooltipKey != null)
                setTooltip(Tooltip.create(Component.translatable(tooltipKey)));
        }
        
        private double current()
        {
            double v = min + value * (max - min);
            v = Math.round(v / step) * step;
            return Mth.clamp(v, min, max);
        }
        
        @Override
        protected void updateMessage()
        {
            if(label == null)
                return;
            
            setMessage(label.apply(current()));
        }
        
        @Override
        protected void applyValue()
        {
            onChange.accept(current());
        }
    }
}
