/*
 * FeedAura standalone - derived from Wurst Client (FeedAuraHack and helpers).
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3 or later. See https://www.gnu.org/licenses/gpl-3.0.txt
 */
package dev.feedaura;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.logging.LogUtils;

import net.fabricmc.loader.api.FabricLoader;

/** All FeedAura settings, saved to config/feedaura.json. */
public final class FeedAuraConfig
{
    public enum LimitMode
    {
        /** Limit applies to how many animals of that species exist nearby. */
        POPULATION,
        /** Limit applies to how many times that species was fed. */
        FED;
        
        public LimitMode next()
        {
            return this == POPULATION ? FED : POPULATION;
        }
    }
    
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON =
        new GsonBuilder().setPrettyPrinting().create();
    private static FeedAuraConfig instance = new FeedAuraConfig();
    
    // ---- original FeedAura settings ----
    public double range = 5;
    public boolean filterBabies = true;
    public boolean filterUntamed = false;
    public boolean filterHorses = false;
    
    // ---- new: counter + limit ----
    public boolean limitEnabled = false;
    public int limit = 20;
    public LimitMode limitMode = LimitMode.POPULATION;
    /** Radius (blocks) used for counting. 0 = every loaded animal. */
    public double countRange = 32;
    
    // ---- new: display ----
    public boolean showHud = true;
    public boolean highlightTarget = true;
    
    public static FeedAuraConfig get()
    {
        return instance;
    }
    
    private static Path path()
    {
        return FabricLoader.getInstance().getConfigDir()
            .resolve("feedaura.json");
    }
    
    public static void load()
    {
        Path path = path();
        if(!Files.exists(path))
        {
            save();
            return;
        }
        
        try(Reader reader = Files.newBufferedReader(path))
        {
            FeedAuraConfig loaded = GSON.fromJson(reader, FeedAuraConfig.class);
            if(loaded != null)
            {
                loaded.sanitize();
                instance = loaded;
            }
            
        }catch(Exception e)
        {
            LOGGER.error("[FeedAura] Could not read config, using defaults", e);
        }
    }
    
    public static void save()
    {
        instance.sanitize();
        try(Writer writer = Files.newBufferedWriter(path()))
        {
            GSON.toJson(instance, writer);
            
        }catch(IOException e)
        {
            LOGGER.error("[FeedAura] Could not save config", e);
        }
    }
    
    private void sanitize()
    {
        range = Math.max(1, Math.min(10, range));
        limit = Math.max(1, Math.min(9999, limit));
        countRange = Math.max(0, Math.min(128, countRange));
        if(limitMode == null)
            limitMode = LimitMode.POPULATION;
    }
}
