# FeedAura (standalone) – tách từ Wurst Client 7.55.1 (MC 1.21.11)

Mod Fabric **client-only**, không cần Wurst. Chỉ cần Fabric Loader + Fabric API.

## Chức năng
**Giữ nguyên từ FeedAuraHack gốc**
- Tự feed động vật đang cầm thức ăn/vật phẩm nhân giống, chọn mục tiêu ngẫu nhiên trong tầm.
- Quay đầu giả (server thấy bạn nhìn con vật, camera của bạn không xoay).
- Settings: Range (1–10), Filter babies, Filter untamed, Filter horse-like.
- Khung highlight xanh→đỏ theo máu mục tiêu.

**Thêm mới**
- **Bộ đếm theo loài** (HUD góc trái trên): ví dụ `Armadillo: 12/20 | đã feed 7`.
  Loài nào nhận vật phẩm đang cầm thì được đếm (cầm lúa mì → cow/sheep/goat... mỗi loài một dòng).
- **Dừng feed khi đủ số lượng** (từng loài riêng). Có 2 chế độ tính:
  - *Số lượng hiện có*: đếm số con của loài đó quanh bạn (tính cả con non).
  - *Số lần đã feed*: đếm số lần FeedAura đã feed loài đó từ lúc bật.
  Khi số lượng tụt xuống dưới mức giới hạn, mod tự feed lại.
- **GUI cài đặt** + lưu file `config/feedaura.json`.
- Tầm đếm (0 = mọi con đã load), bật/tắt HUD, bật/tắt highlight.

## Phím (đổi được trong Controls → FeedAura)
- `J`: bật/tắt FeedAura
- `Right Shift`: mở GUI cài đặt

> Lưu ý: những con đã "in love" vẫn sẽ đẻ thêm con non sau khi bạn dừng, nên hãy đặt giới hạn thấp hơn mức mong muốn một chút.

## Build ra file .jar
Yêu cầu: JDK 21 + Internet (tải Minecraft/Fabric).

Cách A – dùng thẳng project này:
1. Cài Gradle 9.x (hoặc chạy `gradle wrapper` một lần để sinh gradlew).
2. Mở `gradle.properties`, đối chiếu phiên bản `loader_version`, `loom_version`, `fabric_version` với https://fabricmc.net/develop/ (chọn Minecraft 1.21.11).
3. Chạy `gradlew build` → file mod nằm ở `build/libs/feedaura-1.0.0.jar` (không phải `-sources.jar`).

Cách B – an toàn nhất: tạo project mẫu tại https://fabricmc.net/develop/template/ (Minecraft 1.21.11, **Mojang mappings**, id `feedaura`), rồi chép đè `src/` của project này vào và `gradlew build`.

Bỏ file .jar vào thư mục `mods/` cùng Fabric API.

## Nếu build báo lỗi (code chưa được biên dịch thử)
Project được viết bằng cách đọc source Wurst và đổi tên intermediary → Mojang mappings, nhưng **chưa thể build thử** khi viết. Các điểm dễ lệch giữa các bản MC:
1. `util/EntityKinds.java` – dòng import `AbstractHorse` (package có thể là `...animal.equine`).
2. `render/TargetHighlighter.java` + `mixin/LevelRendererMixin.java` – API vẽ (`RenderType.lines()/debugQuads()`, `Camera.position()`). Nếu lỗi, xoá 2 file này và dòng `"LevelRendererMixin"` trong `feedaura.mixins.json` – mod vẫn chạy, chỉ mất khung highlight.
3. `FeedAuraMod.java` – `KeyBindingHelper` / `KeyMapping.Category` / `HudElementRegistry` (tên có thể đổi theo phiên bản Fabric API).

## Giấy phép
Dựa trên mã nguồn Wurst Client (GPL-3.0-or-later), nên mod này cũng phải là GPL-3.0-or-later. Khi phát hành, kèm file `LICENSE` là toàn văn GPLv3 và giữ nguyên các dòng copyright trong đầu file.

## Cách nhanh nhất để ra .jar
- **Trên máy bạn:** cài JDK 21 + Gradle 9.x, rồi chạy `build.sh` (Linux/Mac) hoặc `build.bat` (Windows).
- **Không muốn cài gì:** đẩy thư mục này lên một repo GitHub, vào tab *Actions* → workflow `build` → tải artifact `feedaura-jar`.
