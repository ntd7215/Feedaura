@echo off
REM Can: JDK 21 + Gradle (9.x) + Internet. Chay: build.bat
gradle build
echo Xong! File mod: build\libs\feedaura-1.0.0.jar
pause
