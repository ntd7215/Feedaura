#!/bin/sh
# Cần: JDK 21 + Gradle (9.x) + Internet.  Chạy: ./build.sh
set -e
gradle build
echo "Xong! File mod: build/libs/feedaura-1.0.0.jar"
